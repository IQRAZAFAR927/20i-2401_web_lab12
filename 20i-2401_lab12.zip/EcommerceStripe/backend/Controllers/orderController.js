const Item = require('../models/Items');
const Order = require('../models/Order');


let calculateTotal = (items) => {
    let total = 0;
    return new Promise((resolve, reject) => {
        items.forEach((item, index) => {
            Item.findById(item.item)
                .then(item => {
                    total += item.price * items[index].quantity;
                    if (index == items.length - 1) {
                        resolve(total);
                    }
                })
                .catch(err => {
                    reject(err);
                })
        })
    })
    
}

// -----------------------------Update the AddOrder function------------

let addOrder = async(req, res) => 
{
    let { items } = req.body;
    let user = req.decoded._id;
    let total = 0;
    total = await calculateTotal(items);
    console.log(total);

    // Check if any item already exists in the order
    let existingItem = await Order.findOne({ items: { $elemMatch: { product: items.product } }, user: user });
    if (existingItem) {
        // If an existing item is found, update the quantity
        existingItem.items.forEach(item => {
            if (item.product == items.product) {
                item.quantity += items.quantity;
            }
        });
        // Also update the total amount after adding the same item
        existingItem.total += items.quantity * items.price;
        existingItem.save()
            .then(order => {
                res.status(200).json({ "Success": true, 'Message': 'order updated successfully' });
            })
            .catch(err => {
                res.status(400).json({ "Success": false, 'Message': 'updating order failed', err });
            });
    } else {
        // If no existing item is found, add a new order
        let order = new Order({ items, total, user });
        console.log(order);
        order.save()
            .then(order => {
                res.status(200).json({ "Success": true, 'Message': 'order added successfully' });
            })
            .catch(err => {
                res.status(400).json({ "Success": false, 'Message': 'adding new order failed', err });
            });
    }
}

module.exports = {
    addOrder
}
